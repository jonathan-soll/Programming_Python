from tkinter import *
Label(text='Hello GUI world!').pack()
mainloop()

bcolor = 'light blue'
bfont  = 'Arial'
bsize  = 30
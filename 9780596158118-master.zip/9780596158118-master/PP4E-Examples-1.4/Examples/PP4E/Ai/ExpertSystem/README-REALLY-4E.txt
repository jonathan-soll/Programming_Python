
***PLEASE NOTE***
This code is included for historical context only, and not as 
an example of acceptable Python programming practice today!

This is the holmes expert system shell written in 1993 under 
Python 0.X.  It has not been updated for either Python 3.X
or modern Python best practice in general. 

That is, this is an ex-system.  It has ceased to be.  It would
not vroom if....

See also "Overview-3E.pdf" here for the brief holmes overview
that appeared in the 3rd edition, but which was cut from the 4th.

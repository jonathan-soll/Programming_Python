Various sorts of media files to experiment with as mail attachments.

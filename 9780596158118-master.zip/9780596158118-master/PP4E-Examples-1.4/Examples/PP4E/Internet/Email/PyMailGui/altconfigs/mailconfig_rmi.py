from mailconfig_book import *                 # get base in . (copied from ..)
popservername = 'pop.rmi.net'                 # this is a big inbox: 4800 emails!
popusername   = 'lutz'
myaddress     = 'Mark Lutz <lutz@rmi.net>'    # was just 'lutz@rmi.net' in book
listbg = 'navy'
listfg = 'white'
listHeight = 20         # higher initially
viewbg = '#dbbedc'
viewfg = 'black'
wrapsz = 80             # wrap at 80 cols
fetchlimit = 300        # load more headers

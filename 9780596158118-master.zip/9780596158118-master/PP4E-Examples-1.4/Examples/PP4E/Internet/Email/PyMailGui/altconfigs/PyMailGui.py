import sys                             # ..\PyMailGui.py or 'book' for book configs
sys.path.insert(1, '..')               # add visibility for real dir
exec(open('../PyMailGui.py').read())   # do this, but get mailconfig here

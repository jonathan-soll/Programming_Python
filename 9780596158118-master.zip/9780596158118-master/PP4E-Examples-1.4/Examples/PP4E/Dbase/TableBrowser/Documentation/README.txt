Note: the PDF file reflects Python 2.X and the third edition, but
the source code above this directory has been converted to Python 3.X.
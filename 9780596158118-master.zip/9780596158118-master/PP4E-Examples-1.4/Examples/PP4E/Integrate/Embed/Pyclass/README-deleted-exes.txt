July, 2012: the following Windows+Cygwin executables were 
deleted from this package (recompile from makefiles as needed):

objects.exe
objects-err.exe

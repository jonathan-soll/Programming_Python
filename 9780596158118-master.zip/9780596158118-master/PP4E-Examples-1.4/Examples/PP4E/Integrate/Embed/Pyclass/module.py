# call this class from C to make objects

class klass:
    def method(self, x, y):
        return "brave %s %s" % (x, y)     # run me from C

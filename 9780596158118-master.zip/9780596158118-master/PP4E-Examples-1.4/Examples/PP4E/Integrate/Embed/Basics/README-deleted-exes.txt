July, 2012: the following Windows+Cygwin executables were 
deleted from this package (recompile from makefiles as needed):

embed-bytecode.exe
embed-dict.exe
embed-object.exe
embed-simple.exe
embed-string.exe

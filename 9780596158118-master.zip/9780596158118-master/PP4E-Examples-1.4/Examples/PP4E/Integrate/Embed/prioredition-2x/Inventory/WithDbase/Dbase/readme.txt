Note that shelve files are not necessarily compatible
across platforms or Python releases.  You may need to 
recreate these from scratch.

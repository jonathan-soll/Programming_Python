# simulated orders file/dbase shared by all python tests

orders = [(111, 2, 'GRossum'),       # (product, quantity, buyer) 
          (222, 5, 'LWall'),
          (333, 3, 'JOusterhout'),
          (222, 1, '4Spam'),
          (222, 0, 'LTorvalds'),
          (444, 9, 'ERaymond')]


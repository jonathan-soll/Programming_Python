This is the home directory of the ppembed 2.0 embedding API.
See ppembed.h for most details.  This directory's makefile
generates a library file used in other example directories, 
so there is no expected output here.

